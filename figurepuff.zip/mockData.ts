
import { Figure } from './types';

// Pre-existing figures removed as requested. 
// The gallery starts empty for the creator to populate.
export const MOCK_FIGURES: Figure[] = [];
